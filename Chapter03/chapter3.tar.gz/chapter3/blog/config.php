<?php
/**
 * Config File
 */
$db = [
    'host' => 'localhost',
    'username' => 'root',
    'password' => '786'
];