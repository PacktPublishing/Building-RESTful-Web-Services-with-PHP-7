<?php

$routes = [
    'posts' => 'posts.php',
    'comments' => 'comments.php'
];

