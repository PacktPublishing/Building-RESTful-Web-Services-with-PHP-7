<?php
try {
    // some code
} catch (FirstException | SecondException $e) {
    // handle first and second exceptions
}

